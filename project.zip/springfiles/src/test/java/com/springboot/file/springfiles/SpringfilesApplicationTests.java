package com.springboot.file.springfiles;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringfilesApplicationTests {

	@Test
	void contextLoads() {
	}

}
