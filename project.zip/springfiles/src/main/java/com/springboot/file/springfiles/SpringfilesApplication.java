package com.springboot.file.springfiles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringfilesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringfilesApplication.class, args);
	}

}
