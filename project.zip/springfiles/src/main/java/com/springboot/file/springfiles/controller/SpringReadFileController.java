package com.springboot.file.springfiles.controller;

import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


import com.springboot.file.springfiles.entity.User;
import com.springboot.file.springfiles.service.SpringReadFileService;

@Controller
public class SpringReadFileController {
	@Autowired private SpringReadFileService springReadFileService;

	@CrossOrigin(origins="*")
	@GetMapping(value="/")
	public String home(Model model) {
		model.addAttribute("user", new User());
		List<User> users=springReadFileService.findAll();
		model.addAttribute("users", users);
		return "view/users";
		
	}
	
	@CrossOrigin(origins="*")
	@GetMapping(value="/users")
	public String users(Model model) {
		model.addAttribute("user", new User());
		List<User> users=springReadFileService.findAll();
		model.addAttribute("users", users);
		return "view/onlyusers";
		
	}
	
	
	
	//update Paiement
		@CrossOrigin(origins="*")
		@PostMapping(value ="/calcul",consumes = {MediaType.APPLICATION_JSON_VALUE})
		public String calcul(@RequestBody String body, 
	            HttpServletRequest request,Model model)
		{
			
			
			
			
			body="["+body+"]";
			JSONObject object = null;
			JSONArray array = null;

		
			try {
				array = new JSONArray(body);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
			for(int i=0; i < array.length(); i++)   
			{  
			
			try {
				object = array.getJSONObject(i);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
			}  
			
			List<User> users=springReadFileService.findAll();
			String profession =object.getString("profession");
			int s=0;
			int taille=0;
			
			for(int i=0;i<users.size();i++) {
				if(users.get(i).getProfession().equals(profession)) {
					s+=users.get(i).getSalaire();
					taille++;
				}
				
			}
			
			double moyenne=s/taille;
			
			String m=String.valueOf(moyenne)+" k€";
			
			//System.out.println("la moyenne:"+moyenne);
			model.addAttribute("moyenne", m);
			model.addAttribute("profession", profession);
			return "view/moyenne";
			
		}
	
	
	
	
	
	
	@PostMapping(value="/fileupload")
	public String uploadFile(@ModelAttribute User user, RedirectAttributes redirectAttributes) {
		boolean isFlag=springReadFileService.saveDataFromUploadfile(user.getFile());
		if(isFlag) {
			redirectAttributes.addFlashAttribute("successmessage", "Fichier chargé avec succes");
		}
		else {
			redirectAttributes.addFlashAttribute("errormessage", "Fichier non chargé; veuillez reessayer ");

		}
		
		
		return "redirect:/";
	}
	

	  @PostMapping("/upload")
	  public String uploadFile(@RequestParam("file") MultipartFile file) {
	   
	    boolean isFlag=springReadFileService.saveDataFromUploadfile(file);
		if(isFlag) {
			return "view/success";
			}
		else {
			return "view/error";


		}
	    
	  }

}
